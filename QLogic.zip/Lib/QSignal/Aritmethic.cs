﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.Signal
{
    class Aritmethic
    {
        public static double theta_of_fbw(double fbw) => (Math.PI / 2.0) * (1 - fbw / 2.0);
    }
}
